#include "main.h"

void init();
void gotoxy(int, int);
